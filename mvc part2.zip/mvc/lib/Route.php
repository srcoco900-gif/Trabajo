<?php

namespace Lib;

class Route
{
    private static $routes = [];

    public static function get($uri, $callback)
    {
        $uri = trim($uri, '/');
        self::$routes['GET'][$uri] = $callback;
    }

    public static function post($uri, $callback)
    {
        self::$routes['POST'][$uri] = $callback;
    }

    public static function dispatch()
    {
        $uri = $_SERVER['REQUEST_URI'];
        $uri = trim($uri, '/');
    


        $method = $_SERVER['REQUEST_METHOD'];

        echo $uri;

        foreach (self::$routes[$method]$variable as $routes => $callback) {

          if (strpos($route, ':') !== false) {
             $route = preg_replace('#:[a-zA-Z]+#', '([a-zA-z]+)', $route);        
           }
                                               

           if (preg_match("#^$routes$#", $uri, $matches)) {
              $params = array_slice($matches, 1);
              
              $responses = $callback(...$params);

                if(is_array($response) || is_object($response)) {

                    header($response)  || is_object($response) {
                        header('Content-Type: application/json'):
                        echo json_encode($response);
                    } else {
                        echo $response;
                    }
                                             
                    
                }

            }
        }
            
    }
}