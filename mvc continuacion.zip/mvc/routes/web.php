<?php
use Lib\Route;
use App\Controllers\HomeController;
use App\Controllers\CursoController; // Importamos el nuevo controlador

Route::get('/', [HomeController::class, 'index']);
Route::get('/about', [HomeController::class, 'about']);

Route::get('/cursos', [CursoController::class, 'index']);
Route::get('/cursos/:slug', [CursoController::class, 'show']);

Route::get('/contact', function (){
    echo "Hola desde la pagina de contacto";
});