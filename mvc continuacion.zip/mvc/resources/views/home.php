<?php
/**
 * @var string $title
 * @var string $mensaje
 * @var array $users
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?></title>
</head>
<body>
    <h1><?php echo $mensaje; ?></h1>
    
    <h2>Lista de usuarios (Accediendo como Objetos ->):</h2>
    <ul>
        <?php foreach ($users as $user): ?>
            <li>
                <strong><?php echo $user->name; ?></strong> - 
                <?php echo $user->email; ?> (Tel: <?php echo $user->phone ?? 'N/A'; ?>)
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>