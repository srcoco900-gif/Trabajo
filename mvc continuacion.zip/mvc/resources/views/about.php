<?php
/**
 * @var string $title
 * @var string $curso
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?></title>
</head>
<body>
    <h1>Estás en la sección de detalles</h1>
    <p>Estás viendo el contenido del curso: <strong><?php echo $curso; ?></strong></p>
</body>
</html>