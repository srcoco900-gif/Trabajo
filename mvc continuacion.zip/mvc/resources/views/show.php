<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acerca de</title>
</head>
<body>
    <h1>Acerca de nosotros</h1>
    <p>Esta es la vista de la sección About.</p>
</body>
</html>