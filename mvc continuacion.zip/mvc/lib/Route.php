<?php
namespace Lib;

class Route {
    private static $routes = [];

    public static function get($uri, $callback) {
        $uri = trim($uri, '/');
        self::$routes['GET'][$uri] = $callback;
    }

    public static function post($uri, $callback) {
        $uri = trim($uri, '/');
        self::$routes['POST'][$uri] = $callback;
    }

    public static function dispatch() {
        $uri = $_SERVER['REQUEST_URI'];
        $uri = trim($uri, '/');

        if ($uri == "") {
            $uri = '/';
        }

        $method = $_SERVER['REQUEST_METHOD'];

        foreach (self::$routes[$method] as $route => $callback) {
            
            if ($route == "") {
                $route = '/';
            }

            $pattern = preg_replace('#:[a-zA-Z0-9]+#', '([a-zA-Z0-9-]+)', $route);
            
            if (preg_match("#^$pattern$#", $uri, $matches)) {
                array_shift($matches); 
                
                if (is_array($callback)) {
                    $controller = new $callback[0]();
                    $controller->{$callback[1]}(...$matches);
                    return;
                }
                
                $callback(...$matches);
                return;
            }
        } 

        echo "404 Not Found";
    }
}