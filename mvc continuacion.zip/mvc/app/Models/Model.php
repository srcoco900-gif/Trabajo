<?php
namespace App\Models;

use PDO;
use PDOException;

class Model {
    protected $db_host = 'localhost';
    protected $db_user = 'root';
    protected $db_pass = 'admin'; 
    protected $db_name = 'contacts'; 

    protected $connection;
    protected $table; 

    public function __construct() {
        $this->connection();
    }

    public function connection() {
        try {
            $dsn = "mysql:host={$this->db_host};dbname={$this->db_name};charset=utf8mb4";
            $this->connection = new PDO($dsn, $this->db_user, $this->db_pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC 
            ]);
        } catch (PDOException $e) {
            die("Error de conexión a la base de datos: " . $e->getMessage());
        }
    }

    public function all() {
        $sql = "SELECT * FROM {$this->table}";
        $statement = $this->connection->query($sql);
        return $statement->fetchAll(PDO::FETCH_OBJ);
    }

    public function find($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = :id";
        $statement = $this->connection->prepare($sql);
        $statement->execute(['id' => $id]);
        return $statement->fetch(PDO::FETCH_OBJ);
    }

    
    public function create($data) {
       
        $fields = array_keys($data);
        $placeholders = array_map(function($field) {
            return ":{$field}";
        }, $fields);

      
        $sql = "INSERT INTO {$this->table} (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
        
       
        $statement = $this->connection->prepare($sql);
        $statement->execute($data);

       
        return $this->find($this->connection->lastInsertId());

        
    }

    public function update($id, $data) {
        $fields = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "{$key} = :{$key}";
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $fields) . " WHERE id = :id";
        
        $data['id'] = $id;

        $statement = $this->connection->prepare($sql);
        $statement->execute($data);

        return $this->find($id); 
    }


    public function delete($id) {
        $sql = "DELETE FROM {$this->table} WHERE id = :id";
        
        $statement = $this->connection->prepare($sql);
        $statement->execute(['id' => $id]);
        
        return true;
    }
}