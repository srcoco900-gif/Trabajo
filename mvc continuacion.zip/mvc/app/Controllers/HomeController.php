<?php
namespace App\Controllers;

use App\Models\User;

class HomeController extends Controller {
    
    public function index() {
        $userModel = new User();
        $usuarios = $userModel->all(); 

        return $this->view('home', [
            'title' => 'Home - CRUD',
            'mensaje' => 'Métodos Update y Delete integrados con éxito!',
            'users' => $usuarios 
        ]);
    }

    public function about() {
        return $this->view('about', [
            'title' => 'Nosotros',
            'descripcion' => 'Somos un equipo aprendiendo arquitectura limpia en PHP.'
        ]);
    }
}